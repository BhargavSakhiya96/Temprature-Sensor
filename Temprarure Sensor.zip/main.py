# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import serial
import requests
ser = serial.Serial()
ser.baudrate = 115200
ser.port = 'COM3'
ser.timeout = 1
ser.close()
ser.open()

while 1:
    Data = ser.readline()
    Data = Data.decode('utf-8').split('/')
    r = requests.put('http://esdserver:3000/api/06f11f79ffe776bef883e4f7c0c64a4d/data', json=Data)
    r = requests.get('http://esdserver:3000/api/06f11f79ffe776bef883e4f7c0c64a4d/data')
    print(r.json())


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
